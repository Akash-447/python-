class Node:
    def __init__(self, data=None, next=None):
        self.data = data
        self.next = next

class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if (self.head):
            current = self.head
            while (current.next):
                current = current.next
            current.next = new_node
        else:
            self.head = new_node

    def searchlist(self, value):
        position = 0
        found = 0
        if self.head is None:
            print("The linked list does not exist")
        else:
            temp_node = self.head
            while temp_node is not None:
                position = position + 1
                if temp_node.data == value:
                    print("The required value was found at position:" + str(position))
                    found = 1
                temp_node = temp_node.next
            if found == 0:
                print("The required value does not exist in the list")

    def printll(self):
        current = self.head
        while (current):
            print(current.data)
            current = current.next
    def atbeg(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node

    def delend(self):
        if (self.head == None):
            return
        elif (self.head.next == None):
            self.head = None
        else:
            temp_node = self.head
            while ((temp_node.next).next is not None):
                temp_node = temp_node.next
            print('deleted item = ', (temp_node.next).data)
            temp_node.next = None
        return
LL = LinkedList()
LL.insert(9)
LL.insert(98)
LL.insert('welcome')
LL.insert(23)
print("Contents of list:")
LL.printll()
LL.searchlist(98)
LL.atbeg(5)
print("Contents of list:")
LL.printll()
LL.delend()
LL.delend()
print("Contents of list:")
LL.printll()
