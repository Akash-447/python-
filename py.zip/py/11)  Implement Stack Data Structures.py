

class Stack: 
        def __init__(self, maxSize, top): 
               self.maxSize = maxSize
               self.tops = top
               self.list = [] 
        def __str__(self):
               values = self.list[::-1]  # Reverse the list for stack representation
               values = [str(x) for x in values] 
               return "\n".join(values) 
        def push(self, value): 
               if self.tops == self.maxSize - 1:  # Adjusted condition for full stack
                      print("The stack is full.") 
               else:
                      self.list.append(value) 
                      self.tops += 1 
                      print(value, "Has been successfully added into stack") 
        def pop(self):
               if self.tops == -1: 
                      print("The stack is empty") 
               else:
                      print("Popped item =", self.list.pop())
                      self.tops -= 1 
        def display(self): 
               if self.tops == -1:
                      print("The stack is empty") 
               else: 
                      print("Contents of the stack are:")
                      print(self) 

tempstack = Stack(3, -1) 
tempstack.push(10)
tempstack.push(20) 
tempstack.push(30) 
tempstack.display() 
tempstack.pop()
tempstack.display()