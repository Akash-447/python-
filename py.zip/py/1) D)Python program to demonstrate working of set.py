set1= set()
set2 = set()
for i in range(1,6):
    set1.add(i)
for i in range(3,8):
    set2.add(i)
print("set1 =",set1)
print("\n")
print("set2 =",set2)
print("\n")

