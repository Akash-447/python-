class Node:
    def __init__(self, data=None, next=None):
        self.data = data
        self.next = next


class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if (self.head):
            current = self.head
            while (current.next):
                current = current.next
            current.next = new_node
        else:
            self.head = new_node

    def iterate_item(self):
        current_item = self.head
        while current_item:
            val = current_item.data
            current_item = current_item.next
            yield val

Ll=LinkedList()
Ll.insert(9)
Ll.insert(98)
Ll.insert('Welcome')
Ll.insert(23)
Ll.insert(5)
print("List:")
for val in Ll.iterate_item():
    print(val)
