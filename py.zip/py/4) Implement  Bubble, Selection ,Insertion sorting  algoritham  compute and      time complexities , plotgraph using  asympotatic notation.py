import time
import numpy as np
import matplotlib.pyplot as plt

def selectionsort(array):
    i = 0
    while i < len(array):
        j = i
        k = i + 1
        while k < len(array):
            if array[k] < array[j]:
                j = k
            k = k + 1
        array[i], array[j] = array[j], array[i]
        i = i + 1
def insertionsort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j > 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
def bublesort(array):
    n = len(array) - 1
    while n > 1:
        i = 0
        while i < n:
            if array[i] > array[i + 1]:
                array[i], array[i + 1] = array[i + 1], array[i]
            i = i + 1
        n = n - 1

#main

sorts = [{"name": "selectionsort", "sort": lambda arr: selectionsort(arr)},
         {"name": "Insertion Sort", "sort": lambda arr: insertionsort(arr)},
         {"name": "Bubble sort", "sort": lambda arr: bublesort(arr)}, ]

elements = np.array([i * 1000 for i in range(1, 5)])

plt.xlabel('list length')
plt.ylabel("time comlexity")

for sort in sorts:
    times = list()
    start_all = time.time()
    for i in range(1, 5):
        start = time.time()
        a = np.random.randint(1000, size=i * 1000)
        sort["sort"](a)
        end = time.time()
        times.append(end - start)
        print(sort["name"], "Sorted ", i * 1000, "Elements in", end - start, "s")
    end_all = time.time()
    print(sort["name"], "sorted Elements in", end_all - start_all, "s")
    plt.plot(elements, times, label=sort["name"])
plt.grid()
plt.legend()
plt.show()
