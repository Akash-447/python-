
def factorial(n):
    if (n < 0 or int(n) != n):  # Check for negative or non-integer input
        return "Not defined"
    if (n == 1 or n == 0): 
        return 1 
    else: 
        return n * factorial(n - 1) 

f = int(input("Enter the number: \n"))
print("Factorial of given number =", factorial(f))