Dicti={}
print("empty dictionary")
print(Dicti)
Dicti=dict({1:'monday',2:'tueday',3:'wednesday'})
print("creating dictionary using dict()")
print(Dicti)
Dicti=dict([(1,'january') ,(2,'february')])
print("Dictionary with each item as pair:")
print(Dicti)
