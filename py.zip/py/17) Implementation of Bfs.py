graph = {
    'A': ['B', 'D', 'E', 'F'],
    'D': ['A'],
    'B': ['A', 'F', 'C'],
    'F': ['B', 'A'],
    'C': ['B'],
    'E': ['A']
}
print("given graph is:")
print(graph)

def bfs(input_graph, source):
    visited = set()
    queue = []
    queue.append(source)
    visited.add(source)

    while queue:
        vertex = queue.pop(0)
        print(vertex, end=" ")

        for neighbor in input_graph[vertex]:
            if neighbor not in visited:
                queue.append(neighbor)
                visited.add(neighbor)
print("BFS traversal of graph with source A is:")
bfs(graph, "A")
