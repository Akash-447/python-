t1= (0,)
t2 = (0,1,2,3)
t3 = 0,1,2,3
t4 =('abc',('def','ghi'))
print(t1[0])
print(t3[1:3])
print(len(t3))
tup =(1,"a","string",1+2)
print(tup)
