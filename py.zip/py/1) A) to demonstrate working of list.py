list1=[]
print(" Empty list ")
print(list1)
list1=[10,20,30,40]
print("list containing numbers:")
print(list1)
list1=['mon','tue','wed']
print("list items:")
print(list1)
list1=[['jan','feb'],['march']]
print("multi dimensional  list:", list1)
print(list1)