from datetime import date

class Person:
    def __init__(self, birth_day, birth_month, birth_year):
        self.birthdate = date(birth_year, birth_month, birth_day)
    def get_age(self):
        today = date.today()
        age = today.year - self.birthdate.year - ((today.month, today.day) < (self.birthdate.month, self.birthdate.day))
        return age
birth_day = int(input("Enter the day of your birth: "))
birth_month = int(input("Enter the month of your birth: "))
birth_year = int(input("Enter the year of your birth: "))
person1 = Person(birth_day, birth_month, birth_year)
age = person1.get_age()
print("Your age is:", age)
