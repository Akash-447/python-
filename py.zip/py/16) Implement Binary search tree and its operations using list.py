class BstNode:
    def __init__(self, data):
        self.leftChild = None
        self.rightChild = None
        self.data = data

    # function to insert node in bst
    def insertnode(self, node_value):
        if self.data is None:
            self.data = node_value
        elif node_value <= self.data:
            if self.leftChild is None:
                self.leftChild = BstNode(node_value)
            else:
                self.leftChild.insertnode(node_value)
        else:
            if self.rightChild is None:
                self.rightChild = BstNode(node_value)
            else:
                self.rightChild.insertnode(node_value)

    def minValueNode(self):
        current = self
        while current.leftChild is not None:
            current = current.leftChild
        return current

    def deleteNode(self, node_value):
        if self is None:
            print(node_value, "Can't be deleted as its not found")
            return self
        if node_value < self.data:
            if self.leftChild is not None:
                self.leftChild = self.leftChild.deleteNode(node_value)
        elif node_value > self.data:
            if self.rightChild is not None:
                self.rightChild = self.rightChild.deleteNode(node_value)
        else:
            if self.leftChild is None:
                temp = self.rightChild
                print("Element deleted successfully")
                self = None
                return temp
            if self.rightChild is None:
                temp = self.leftChild
                print("Element deleted successfully")
                self = None
                return temp

            temp = self.rightChild.minValueNode()
            self.data = temp.data
            self.rightChild = self.rightChild.deleteNode(temp.data)
        return self

    def searchNode(self, node_value):
        if self is None or self.data == node_value:
            return
        if node_value < self.data:
            if self.rightChild is not None:
                return self.leftChild.searchNode(node_value)
        else:
            if self.rightChild is not None:
                return self.rightChild.searchNode(node_value)
        return None

    def inOrderTraversal(self):
        if self is not None:
            if self.leftChild is not None:
                self.leftChild.inOrderTraversal()
            print(self.data)
            if self.rightChild is not None:
                self.rightChild.inOrderTraversal()


r = BstNode(50)
r.insertnode(30)
r.insertnode(20)
r.insertnode(40)
r.insertnode(70)
r.insertnode(60)
r.insertnode(80)
print("inorder traversal of tree:")
r.inOrderTraversal()
print("Searching for node wit value 20 :")
result = r.searchNode(20)
if result:
    print("the element has been found")
else:
    print("The element was not found")
print("Deleting node with value 50:")
r.deleteNode(50)
print("Inorder traversal after deleting node 50:")
r.inOrderTraversal()

